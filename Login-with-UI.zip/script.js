document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault(); //Evitar que se envíe el formulario


    // Obtener valores de entrada
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    //Validacion basica de login
    if (username === 'le07112002' && password === 'Pas@0711*') {
        // Si el usuario es correo mostramos un mensaje de ¡Inicio de sesión exitoso!
        alert('¡Inicio de sesión exitoso!');
        // Limpia el formato para que se utilize de nuevo
        document.getElementById('login-form').reset();
        // Mensaje de error que no es correcto
        document.getElementById('error-message').textContent = '';
    } else {
        document.getElementById('error-message').textContent = 'Usuario o contraseña incorrectos';
    }
});